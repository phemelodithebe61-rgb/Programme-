# Rubric checklist (based on screenshots supplied)

| Rubric requirement | Marks | Evidence | Status |
|---|---:|---|---|
| General: good practices, correct variable types/scope/names | 3 | All source files, separate packages | Implemented |
| General: efficient, maintainable code | 2 | Reused model methods and GUI actions | Implemented |
| General: meaningful comments | 3 | Interface, model, GUI and report comments | Implemented |
| General: compiles and executes | 2 | Ant build and runnable JARs | Verified compilation |
| Q1: display rows and columns | 5 | `question1/ProductSalesReport.java` | Implemented |
| Q1: total and average sales | 5 | `question1/ProductSales.java` and report | Implemented |
| Q1: highest and lowest sales | 5 | `question1/ProductSales.java` and report | Implemented |
| Q1: interface and implementing class | 5 | `question1/IProduct.java`, `IProductSales.java`, `ProductSales.java` | Implemented |
| Q1: total-sales unit test | 5 | `test/question1/ProductSalesTest.java` | Implemented |
| Q1: average-sales unit test | 5 | `test/question1/ProductSalesTest.java` | Implemented |
| Q2: GUI with buttons, area, years label | 10 | `question2/ProductSalesApplication.java` | Implemented |
| Q2: File/Tools menu system | 5 | `question2/ProductSalesApplication.java` | Implemented |
| Q2: sample report in text area | 10 | `loadData()` and `report()` | Implemented |
| Q2: file saved correctly | 5 | `saveData()`, `sample-output/data.txt` | Implemented |
| Q2: IProductSales interface | 5 | `question2/IProductSales.java` | Implemented |
| Q2: ProductSales class with methods | 10 | `question2/ProductSales.java` | Implemented |
| Q2: years processed | 5 | `GetProductsProcessed()` and years label | Implemented |
| Q2: over-limit test | 5 | `test/question2/ProductSalesTest.java` | Implemented |
| Q2: under-limit test | 5 | `test/question2/ProductSalesTest.java` | Implemented |

**Total rubric allocation: 100 marks (10 + 30 + 60).** Actual grading is determined by the examiner. The GUI appearance is similar in structure to the screenshot, but may vary by OS and Swing look-and-feel. GUI visual operation needs to be confirmed on a desktop computer.
