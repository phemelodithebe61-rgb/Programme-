package question2;
/** Model for two years of sound-equipment sales; limit is strictly greater/less than 500. */
public class ProductSales implements IProductSales {
    public static final int SALES_LIMIT = 500;
    private final int[][] sales;
    public ProductSales() { this(new int[][] {{300, 150, 700}, {250, 200, 600}}); }
    public ProductSales(int[][] input) {
        if (input == null || input.length == 0) throw new IllegalArgumentException("Years are required");
        sales = new int[input.length][];
        for (int i = 0; i < input.length; i++) {
            if (input[i] == null || input[i].length == 0) throw new IllegalArgumentException("Sales are required");
            sales[i] = input[i].clone();
        }
    }
    @Override public int[][] GetProductSales() {
        int[][] copy = new int[sales.length][];
        for (int i = 0; i < sales.length; i++) copy[i] = sales[i].clone();
        return copy;
    }
    @Override public int GetTotalSales() {
        int total = 0;
        for (int[] row : sales) for (int value : row) total += value;
        return total;
    }
    @Override public int GetSalesOverLimit() {
        int count = 0;
        for (int[] row : sales) for (int value : row) if (value > SALES_LIMIT) count++;
        return count;
    }
    @Override public int GetSalesUnderLimit() {
        int count = 0;
        for (int[] row : sales) for (int value : row) if (value < SALES_LIMIT) count++;
        return count;
    }
    @Override public int GetProductsProcessed() { return sales.length; } // Years processed per sample output
    @Override public double GetAverageSales() {
        int count = 0;
        for (int[] row : sales) count += row.length;
        return (double) GetTotalSales() / count;
    }
}
