package question2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
/** Swing GUI with reusable actions shared by buttons and menu items. */
public class ProductSalesApplication extends JFrame {
    private final ProductSales model = new ProductSales();
    private final JTextArea output = new JTextArea(7, 29);
    private final JLabel yearsLabel = new JLabel("Years Processed: ");
    public ProductSalesApplication() {
        super("Product Sales Application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));
        JPanel center = new JPanel(new BorderLayout(6, 6));
        center.setBorder(BorderFactory.createEmptyBorder(12, 14, 8, 14));
        JPanel buttons = new JPanel(new GridLayout(2, 1, 5, 5));
        JButton load = new JButton("Load Product Data");
        JButton save = new JButton("Save Product Data");
        load.addActionListener(e -> loadData());
        save.addActionListener(e -> saveData());
        buttons.add(load); buttons.add(save);
        center.add(buttons, BorderLayout.NORTH);
        output.setEditable(false);
        output.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        center.add(new JScrollPane(output), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.LEFT));
        footer.add(yearsLabel); add(footer, BorderLayout.SOUTH);
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exit = new JMenuItem("Exit");
        exit.addActionListener(e -> dispose());
        fileMenu.add(exit);
        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem loadItem = new JMenuItem("Load Product Data");
        JMenuItem saveItem = new JMenuItem("Save Product Data");
        JMenuItem clearItem = new JMenuItem("Clear");
        loadItem.addActionListener(e -> loadData());
        saveItem.addActionListener(e -> saveData());
        clearItem.addActionListener(e -> clearData());
        toolsMenu.add(loadItem); toolsMenu.add(saveItem); toolsMenu.add(clearItem);
        menuBar.add(fileMenu); menuBar.add(toolsMenu); setJMenuBar(menuBar);
        pack(); setMinimumSize(new Dimension(360, 300)); setLocationRelativeTo(null);
    }
    private void loadData() {
        output.setText(report());
        yearsLabel.setText("Years Processed: " + model.GetProductsProcessed());
    }
    private String report() {
        return "Total Sales: " + model.GetTotalSales() + "\n"
             + "Average Sales: " + Math.round(model.GetAverageSales()) + "\n"
             + "Sales over limit: " + model.GetSalesOverLimit() + "\n"
             + "Sales under limit: " + model.GetSalesUnderLimit();
    }
    private void saveData() {
        if (output.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Load product data before saving.", "No data", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String contents = "DATA LOG\n" + "***********************************\n"
            + output.getText() + "\n***********************************\n";
        try {
            Path target = Path.of("data.txt");
            Files.writeString(target, contents, StandardCharsets.UTF_8);
            JOptionPane.showMessageDialog(this, "Saved to: " + target.toAbsolutePath());
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Unable to save: " + ex.getMessage(), "Save error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void clearData() { output.setText(""); yearsLabel.setText("Years Processed: "); }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductSalesApplication().setVisible(true));
    }
}
