package question1;
/** Console application using a two-dimensional sales array and a one-dimensional year-label array. */
public class ProductSalesReport {
    public static void main(String[] args) {
        int[][] data = {{300, 150, 700}, {250, 200, 600}};
        String[] years = {"YEAR 1", "YEAR 2"};
        ProductSales sales = new ProductSales();
        System.out.println("PRODUCT SALES REPORT - 2025");
        System.out.println("---------------------------------------");
        System.out.printf("%-10s %10s %10s %10s%n", "YEAR", "QUARTER 1", "QUARTER 2", "QUARTER 3");
        for (int i = 0; i < data.length; i++)
            System.out.printf("%-10s %10d %10d %10d%n", years[i], data[i][0], data[i][1], data[i][2]);
        System.out.println("---------------------------------------");
        System.out.println("Total sales:   " + sales.TotalSales(data));
        System.out.println("Average sales: " + Math.round(sales.AverageSales(data)));
        System.out.println("Maximum sale:  " + sales.MaxSale(data));
        System.out.println("Minimum sale:  " + sales.MinSale(data));
        System.out.println("---------------------------------------");
    }
}
