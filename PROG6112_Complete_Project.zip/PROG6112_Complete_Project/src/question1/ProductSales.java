package question1;
/** Calculates the sales statistics without duplicating calculation logic. */
public class ProductSales implements IProductSales {
    private static void validate(int[][] values) {
        if (values == null || values.length == 0) throw new IllegalArgumentException("Sales cannot be empty");
        for (int[] row : values) if (row == null || row.length == 0) throw new IllegalArgumentException("Each year needs sales");
    }
    private static int count(int[][] values) {
        int n = 0;
        for (int[] row : values) n += row.length;
        return n;
    }
    @Override public int TotalSales(int[][] productSales) {
        validate(productSales);
        int total = 0;
        for (int[] row : productSales) for (int sale : row) total += sale;
        return total;
    }
    @Override public double AverageSales(int[][] productSales) {
        validate(productSales);
        return (double) TotalSales(productSales) / count(productSales);
    }
    @Override public int MaxSale(int[][] productSales) {
        validate(productSales);
        int max = Integer.MIN_VALUE;
        for (int[] row : productSales) for (int sale : row) max = Math.max(max, sale);
        return max;
    }
    @Override public int MinSale(int[][] productSales) {
        validate(productSales);
        int min = Integer.MAX_VALUE;
        for (int[] row : productSales) for (int sale : row) min = Math.min(min, sale);
        return min;
    }
}
