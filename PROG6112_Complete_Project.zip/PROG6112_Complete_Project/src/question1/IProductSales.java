package question1;
/** Alternative interface name mentioned in the question narrative. */
public interface IProductSales extends IProduct { }
