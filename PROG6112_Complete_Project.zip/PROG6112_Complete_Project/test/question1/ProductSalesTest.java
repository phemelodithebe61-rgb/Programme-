package question1;
import org.junit.Test;
import static org.junit.Assert.*;
/** Required Question 1 tests plus coverage for extrema. */
public class ProductSalesTest {
    private final ProductSales sales = new ProductSales();
    private final int[][] data = {{300,150,700},{250,200,600}};
    @Test public void CalculateTotalSales_ReturnsTotalSales() { assertEquals(2200, sales.TotalSales(data)); }
    @Test public void AverageSales_ReturnsAverageProductSales() { assertEquals(2200.0 / 6, sales.AverageSales(data), 0.00001); }
    @Test public void maximumAndMinimumSales() { assertEquals(700, sales.MaxSale(data)); assertEquals(150, sales.MinSale(data)); }
}
