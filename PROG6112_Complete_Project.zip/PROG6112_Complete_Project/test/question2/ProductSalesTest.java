package question2;
import org.junit.Test;
import static org.junit.Assert.*;
/** Required Question 2 tests and other calculation checks. */
public class ProductSalesTest {
    private final ProductSales sales = new ProductSales();
    @Test public void GetSalesOverLimit_ReturnsNumberOfSales() { assertEquals(2, sales.GetSalesOverLimit()); }
    @Test public void GetSalesUnderLimit_ReturnsNumberOfSales() { assertEquals(4, sales.GetSalesUnderLimit()); }
    @Test public void otherSalesCalculations() {
        assertEquals(2200, sales.GetTotalSales());
        assertEquals(2200.0 / 6, sales.GetAverageSales(), 0.00001);
        assertEquals(2, sales.GetProductsProcessed());
        assertArrayEquals(new int[] {300,150,700}, sales.GetProductSales()[0]);
    }
    @Test public void limitIsStrict() {
        ProductSales boundary = new ProductSales(new int[][] {{499,500,501}});
        assertEquals(1, boundary.GetSalesOverLimit());
        assertEquals(1, boundary.GetSalesUnderLimit());
    }
}
