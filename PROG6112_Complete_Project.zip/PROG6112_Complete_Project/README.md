# PROG6112 Java Sales Applications — Questions 1 and 2

## Requirements
Java JDK 17 or later, Apache Ant, and JUnit 4 for the unit tests. Source code is plain Java and opens in NetBeans using **File > New Project > Java with Ant > Java Project with Existing Sources**, selecting the `src` and `test` folders. Alternatively open `build.xml` as an Ant build file in NetBeans. No external dependencies are needed to run either application.

## Run
From the project directory:

- `ant run-q1` — console report for Question 1.
- `ant run-q2` — Swing desktop application for Question 2 (requires graphical desktop).
- `ant jar` — creates both runnable JARs in `dist`.
- `java -jar dist/Question1-Console.jar`
- `java -jar dist/Question2-GUI.jar`
- `ant test` — JUnit 4 tests (on systems without `/usr/share/java/junit4.jar`, set `-Djunit.jar=/path/to/junit4.jar`; include Hamcrest in your local classpath if your JUnit distribution needs it).

## Question 2 instructions
Click **Load Product Data** to calculate and show the four statistics and years processed. Click **Save Product Data** to write `data.txt` in the application's current working directory. Menu **Tools** provides Load, Save and Clear with the same actions. Menu **File > Exit** closes the application. Clear empties the report and resets the years label.

## Sample values
Sales: Year 1 [300,150,700], Year 2 [250,200,600]. Total 2200; average 366.666... displayed as 367; maximum 700; minimum 150; above 500 = 2; below 500 = 4; years = 2.

## Notes
- The Q1 prompt calls the interface `IProductSales` in prose but displays code headed `IProduct`. Both names are provided: `IProductSales` extends `IProduct` and `ProductSales` implements `IProductSales`.
- Q2 `GetProductsProcessed()` returns **years processed** (2), matching the specified GUI sample, despite its name.
- Values equal to 500 are neither over nor under the limit.
- The `data.txt` file is generated at runtime, and a sample file is also provided in `sample-output/`.
- The provided screenshots show Question 1 as 30 marks and Question 2 as 60 marks; General Requirements are 10 marks. Marks are not guaranteed by any code checklist.
